function printNumbers() {
    for (let i = 0; i <= 100; i++) {
        console.log(i);
    }
}

printNumbers();