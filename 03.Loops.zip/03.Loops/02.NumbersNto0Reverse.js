function numbersReverse(n) {
    for (let i = n; i >= 0; i--) {
        console.log(i);
    }
}

numbersReverse(10);
