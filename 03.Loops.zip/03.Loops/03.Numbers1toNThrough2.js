function printOddNumbers(n) {
    for (let i = 1; i <= n; i += 2) {
        console.log(i);
    }
}

printOddNumbers(10);

