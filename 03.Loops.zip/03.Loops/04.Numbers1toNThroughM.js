function customLoop(n, m) {
    for (let i = 1; i <= n; i += m) {
        console.log(i);
    }
}

customLoop(10, 2);
customLoop(8, 3);