function printLetters(word) {
    for (let i = 0; i < word.length; i++) {
        console.log(word[i]);
    }
}

printLetters("hello");
printLetters("Bulgaria");