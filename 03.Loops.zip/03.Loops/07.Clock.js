function clock() {
    for (let i = 0; i < 24; i++) {
        for (let j = 0; j < 60; j++) {
            console.log(`${i}:${j}`);
        }
    }
}

clock();