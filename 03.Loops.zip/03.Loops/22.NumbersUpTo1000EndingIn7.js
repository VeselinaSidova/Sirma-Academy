function printNumbersEndingInSeven() {
    for (let i = 7; i < 1000; i += 10) {
        console.log(i);
    }
}

printNumbersEndingInSeven();