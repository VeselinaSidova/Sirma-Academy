function printNumbersEndingInN(n) {
    for (let i = n; i < 1000; i += 10) {
        console.log(i);
    }
}

printNumbersEndingInN(6);
printNumbersEndingInN(8);